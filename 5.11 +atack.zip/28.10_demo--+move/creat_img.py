from PIL import Image, ImageDraw
from math import cos, pi, sin


def pole_img(images, rows=11, cols=11):
    new_image = Image.new("RGB", (rows * 80, cols * 80), (0, 0, 0))
    for i in range(rows):
        for j in range(cols):
            im = Image.open(images[i][j].img())
            new_image.paste(im, (i * 80, j * 80))
    new_image.save('img/play.png')


# def xs(x):
#     return 80 // 2 + x
#
#
# def ys(y):
#     return 80 // 2 - y
#
#
# def town_img(level, name):
#     new_image = Image.new("RGB", (80, 80), (128, 255, 0))
#     n = level + 2
#     nodes = [(35 * cos(i * 2 * pi / n),
#               35 * sin(i * 2 * pi / n))
#              for i in range(n)]
#     nodes2 = [(int(xs(node[0])),
#                int(ys(node[1]))) for node in nodes]
#     print(nodes2)
#     nodes2 = tuple(nodes2)
#     print(nodes2)
#     draw = ImageDraw.Draw(new_image)
#     draw.polygon(
#         nodes2, '#bF311A'
#     )
#     new_image.save(name)
#
#
# town_img(5, 'tst.png')
