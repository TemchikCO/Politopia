import sys
from PyQt5 import Qt, uic
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QLabel, QMainWindow, QFileDialog, QDialog, QInputDialog, QMessageBox, \
    QPushButton, QWidget
from PyQt5 import QtCore


from start import Ui_MainWindow
from style import btm_start, main_background

SCREEN_SIZE = [1920, 1080]


class Start(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.Hero_1_Window = QWidget(self)
        uic.loadUi("ui/Hero_1_characteristic.ui", self.Hero_1_Window)
        self.pixmap = QPixmap('img/Hero_1_img.png')
        self.Hero_1_Window.Hero_photo.setPixmap(self.pixmap)
        self.Hero_1_Window.hide()
        self.Hero_2_Window = QWidget(self)
        uic.loadUi("ui/Hero_2_characteristic.ui", self.Hero_2_Window)
        self.pixmap = QPixmap('img/avatar.png')
        self.Hero_2_Window.Hero_photo.setPixmap(self.pixmap)
        self.Hero_2_Window.hide()
        self.Hero_3_Window = QWidget(self)
        uic.loadUi("ui/Hero_3_characteristic.ui", self.Hero_3_Window)
        self.pixmap = QPixmap('img/avatar.png')
        self.Hero_3_Window.Hero_photo.setPixmap(self.pixmap)
        self.Hero_3_Window.hide()
        self.Hero_4_Window = QWidget(self)
        uic.loadUi("ui/Hero_4_characteristic.ui", self.Hero_4_Window)
        self.pixmap = QPixmap('img/Hero_4_img.png.png')
        self.Hero_4_Window.Hero_photo.setPixmap(self.pixmap)
        self.Hero_4_Window.hide()
        self.resize(*SCREEN_SIZE)
        self.setStyleSheet(main_background)
        self.pushButton.setStyleSheet(btm_start)
        self.pushButton_2.setStyleSheet(btm_start)
        self.pushButton.clicked.connect(self.run)

    def reverse(self):
        uic.loadUi("ui/start.ui", self)
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()
        self.pushButton.setStyleSheet(btm_start)
        self.pushButton_2.setStyleSheet(btm_start)
        self.pixmap = QPixmap('img/avatar.png')
        self.label.setPixmap(self.pixmap)
        self.label.setGeometry(810, 250, 300, 217)
        self.pushButton_2.setGeometry(820, 540, 280, 90)
        self.pushButton.clicked.connect(self.run)

    def run(self):
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()
        uic.loadUi("ui/chose_hero.ui", self)
        self.ReverseButton.setStyleSheet(btm_start)
        self.ReverseButton.clicked.connect(self.reverse)
        self.Hero_1.setStyleSheet(btm_start)
        self.Hero_2.setStyleSheet(btm_start)
        self.Hero_3.setStyleSheet(btm_start)
        self.Hero_4.setStyleSheet(btm_start)
        self.Hero_1.clicked.connect(self.Hero_1_characteristic)
        self.Hero_2.clicked.connect(self.Hero_2_characteristic)
        self.Hero_3.clicked.connect(self.Hero_3_characteristic)
        self.Hero_4.clicked.connect(self.Hero_4_characteristic)

    def Hero_1_characteristic(self):
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()
        self.Hero_1_Window.setGeometry(1300, 200, 600, 500)
        self.Hero_1_Window.setStyleSheet('background: purple')
        self.Hero_1_Window.show()
        self.Hero_1_Window.Yes_button.clicked.connect(self.hero_chosed)
        self.Hero_1_Window.No_button.clicked.connect(self.run)

    def Hero_2_characteristic(self):
        self.Hero_1_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()
        self.Hero_2_Window.setGeometry(1300, 200, 600, 500)
        self.Hero_2_Window.setStyleSheet('background: red')
        self.Hero_2_Window.show()
        self.Hero_2_Window.Yes_button.clicked.connect(self.hero_chosed)
        self.Hero_2_Window.No_button.clicked.connect(self.run)

    def Hero_3_characteristic(self):
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_4_Window.hide()
        self.Hero_3_Window.setGeometry(1300, 200, 600, 500)
        self.Hero_3_Window.setStyleSheet('background: #FFFF00')
        self.Hero_3_Window.show()
        self.Hero_3_Window.Yes_button.clicked.connect(self.hero_chosed)
        self.Hero_3_Window.No_button.clicked.connect(self.run)

    def Hero_4_characteristic(self):
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.setGeometry(1300, 200, 600, 500)
        self.Hero_4_Window.setStyleSheet('background: green')
        self.Hero_4_Window.show()
        self.Hero_4_Window.Yes_button.clicked.connect(self.hero_chosed)
        self.Hero_4_Window.No_button.clicked.connect(self.run)

    # def confirmation(self):
    #     msgBox = QMessageBox()
    #     msgBox.setWindowTitle("Начать игру?")
    #     msgBox.setText("")
    #     msgBox.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
    #     ret = msgBox.exec_()
    #
    #     if ret == QMessageBox.Yes:
    #         self.hero_chosed()
    #     if ret == QMessageBox.No:
    #         self.run()

    def hero_chosed(self):
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()
        uic.loadUi("ui/play.ui", self)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Start()
    ex.show()
    sys.exit(app.exec_())
