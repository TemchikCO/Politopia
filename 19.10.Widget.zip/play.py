import sys

from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QLabel, QGridLayout, QWidget, QVBoxLayout, QGroupBox
from PyQt5.QtCore import QRect

from style import btm_start, main_background
from creation import field_creation


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.resize(1920, 1080)
        self.setWindowTitle('PLAY')
        # self.setStyleSheet(main_background)

        self.texnologes = QPushButton('Технологии', self)
        self.texnologes.setStyleSheet(btm_start)
        self.texnologes.setGeometry(835, 950, 100, 40)

        self.next = QPushButton('Следующий ход', self)
        self.next.setStyleSheet(btm_start)
        self.next.setGeometry(985, 950, 100, 40)

        self.x = 520
        self.y = 50
        # создание grid
        self.centralwidget = QWidget(self)
        self.gridLayoutWidget = QWidget(self.centralwidget)
        self.gridLayoutWidget.setGeometry(QRect(self.x, self.y, 880, 900))
        self.gridLayoutWidget.setObjectName("gridLayoutWidget")
        self.grid = QGridLayout(self.gridLayoutWidget)
        self.grid.setContentsMargins(0, 0, 0, 0)
        pole = field_creation()

        for i in range(11):
            for j in range(11):
                label = QLabel(self.gridLayoutWidget)
                label.resize(80, 80)
                label.setPixmap(QPixmap(pole[i][j].img()))
                self.grid.addWidget(label, i, j)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWindow()
    ex.show()
    sys.exit(app.exec_())
