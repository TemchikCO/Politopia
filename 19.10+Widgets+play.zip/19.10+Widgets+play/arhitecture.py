class Cell:
    def __init__(self):
        pass

    def img(self):
        return 'img/cell_def.png'


class Town(Cell):
    def __init__(self):
        super().__init__()
        self.level = 0

    def img(self):
        return 'img/town.png'


class Resources(Cell):
    def __init__(self):
        super().__init__()
        self.level = 0

    def img(self):
        return 'img/resource.png'


class Unit:
    # это две картинки: 1 -  мы видим всегда (сам unit), 2 - show(), когда нажимаем на Unitа (область возможного хода)
    def __init__(self):
        pass

    def move(self):
        pass

# technologies
