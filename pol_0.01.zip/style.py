btm_start = """QPushButton{font-style: oblique;
                                    font-weight: bold;
                                    border: 1px solid #1DA1F2;
                                    border-radius: 15px;
                                    color: #1DA1F2;
                                    background-color: #fff;
                                }
                                """
main_background = """
                            QMainWindow {
                                background-image: url("img/main.jpg");
                                background-repeat: no-repeat; 
                                background-position: center;
                            }
                        """
widget_background = """
                            QWidget {
                                background-image: url("img/main.jpg");
                                background-repeat: no-repeat; 
                                background-position: center;
                            }
                        """