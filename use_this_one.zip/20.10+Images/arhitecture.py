from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QLabel
from PyQt5.QtGui import QPixmap


class Cell:
    def __init__(self):
        pass

    def img(self):
        return 'img/cell/cell_def.png'


class Town_demo(Cell):
    def __init__(self):
        super().__init__()

    def img(self):
        return 'img/cell/town/town_0.png'


class Town:
    def __init__(self, x, y, cord_x, cord_y, pole):
        super().__init__()
        self.level = 1
        self.x = x
        self.y = y
        self.cord_x = cord_x
        self.cord_y = cord_y
        self.pole = pole
        self.img()

    def img(self):
        self.pict = QLabel(self.pole)
        self.pict.setGeometry(self.x + self.cord_x * 80, self.y + self.cord_y * 80, 80, 80)
        self.pict.setPixmap(QPixmap(f'img/cell/town/town_{self.level}.png'))
        # return f'img/cell/town/town_{self.level}.png'

    def level_pl(self):
        self.level += 1
        self.img()


class Resources(Cell):
    def __init__(self):
        super().__init__()

    def img(self):
        return 'img/cell/resource.png'


class Unit:
    # это две картинки: 1 -  мы видим всегда (сам unit), 2 - show(), когда нажимаем на Unitа (область возможного хода)
    def __init__(self, x, y, cord_x, cord_y, pole):
        self.x = x
        self.y = y
        self.pole = pole
        self.pict = QLabel(pole)
        self.pict.setGeometry(x + cord_x * 80, y + cord_y * 80, 80, 80)
        self.pict.setPixmap(QPixmap('img/heros_with_bow/Hero_3_with_bow.png'))
        pass

    def move(self):
        # реализовать область возможных ходов
        # обновить координаты в соответствии с кликнутым labelом
        pass

    # def img(self):
    #     'img/unit.png'

# technologies
