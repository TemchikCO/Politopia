from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QLabel
from PyQt5.QtGui import QPixmap

POLE_Y = 11
POLE_X = 11


class Cell:
    def __init__(self):
        pass

    def img(self):
        return 'img/cell/cell_def.png'


class Town(Cell):
    def __init__(self):
        super().__init__()

    def img(self):
        return 'img/cell/town/town_0.png'

    def cord(self, x, y, cord_x, cord_y, pole, player):
        super().__init__()
        self.level = 1
        self.x = x
        self.y = y
        self.cord_x = cord_x
        self.cord_y = cord_y
        self.pole = pole
        self.player = player
        self.label()

    def label(self):
        self.pict = QLabel(self.pole)
        self.pict.setGeometry(self.x + self.cord_x * 80, self.y + self.cord_y * 80, 80, 80)
        self.pict.setPixmap(QPixmap(f'img/cell/town/town_{self.level}.png'))

        self.border = QLabel(self.pole)
        self.border.setGeometry(self.x + self.cord_x * 80 - 80, self.y + self.cord_y * 80 - 80, 240, 240)
        if self.player:
            self.border.setPixmap(QPixmap('img/border/blue_border.png'))
        else:
            self.border.setPixmap(QPixmap('img/border/red_border.png'))

    def level_pl(self):
        self.level += 1
        self.img()


class Resources(Cell):
    def __init__(self):
        super().__init__()

    def img(self):
        return 'img/cell/resource.png'


class Unit:
    # это две картинки: 1 -  мы видим всегда (сам unit), 2 - show(), когда нажимаем на Unitа (область возможного хода)
    def __init__(self, x, y, cord_x, cord_y, pole):
        self.cord_x = cord_x
        self.cord_y = cord_y
        self.x = x
        self.y = y
        self.pole = pole
        self.pict = QLabel(pole)
        self.pict.setGeometry(self.x + cord_x * 80, self.y + cord_y * 80, 80, 80)
        self.pict.setPixmap(QPixmap('img/heros_with_bow/Hero_3_with_bow.png'))
        self.xod = 1
        self.oblast = []
        for y in range(-self.xod, self.xod + 1):
            oblast = []
            for x in range(-self.xod, self.xod + 1):
                label = QLabel(pole)
                label.setPixmap(QPixmap('img/targets/new_move_terget.png'))
                label.setGeometry(self.x + (cord_x + x) * 80, self.y + (cord_y + y) * 80, 80, 80)
                label.hide()
                oblast.append([label, False])  # можно ли кликнуть на label
            self.oblast.append(oblast)
        pass

    def create_moves_oblast(self, blue_units, red_units):
        # срабатывает при нажатии на unit
        # генериться область в котороую можно сходить (с учетом исключений)
        # в Label
        y_a = 0
        y_b = 0
        x_a = 0
        x_b = 0
        print(y_a, y_a, x_a, x_b)
        if self.cord_y < 1:
            y_a = 1
        if self.cord_x < 1:
            x_a = 1
        if self.cord_y > POLE_Y - self.xod - 1:
            y_b = 1
        if self.cord_x > POLE_X - self.xod - 1:
            x_b = 1
        for y in range(-(self.xod - y_a), self.xod + 1 - y_b):
            for x in range(-(self.xod - x_a), self.xod + 1 - x_b):
                if self.chek_unit(self.cord_x + x, self.cord_y + y, blue_units, red_units):
                    self.oblast[y + self.xod][x + self.xod][0].show()
                    self.oblast[y + self.xod][x + self.xod][1] = True
                else:
                    self.oblast[y + self.xod][x + self.xod][1] = False
        pass

    def hide_oblast(self):
        for i in range(len(self.oblast)):
            for j in range(len(self.oblast[0])):
                self.oblast[i][j][0].hide()
                self.oblast[i][j][1] = False

    def coords(self):
        return self.cord_x, self.cord_y

    def chek_unit(self, x, y, blue_units, red_units):
        for i in blue_units:
            if (x, y) == i.coords():
                return False
        for i in red_units:
            if (x, y) == i.coords():
                return False
        return True

    def move_oblast(self, x, y, blue_units, red_units):
        for y_ in range(-self.xod, self.xod + 1):
            for x_ in range(-self.xod, self.xod + 1):
                self.oblast[y_ + self.xod][x_ + self.xod][0].move(self.x + (x_ + x) * 80, self.y + (y_ + y) * 80)
                self.create_moves_oblast(blue_units, red_units)

    def move_unit(self, x, y, blue_units, red_units):
        if self.oblast[abs(self.cord_y - self.xod - y)][abs(self.cord_x - self.xod - x)][1]:
            self.pict.move(self.x + 80 * x, self.y + 80 * y)
            self.move_oblast(x, y, blue_units, red_units)
            self.cord_x = x
            self.cord_y = y
# technologies
