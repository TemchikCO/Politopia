import sys

from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QLabel, QGridLayout, QWidget, QVBoxLayout, \
    QGroupBox, QMessageBox
from PyQt5.QtCore import QRect

from style import btm_start, main_background
from creation import field_creation
from arhitecture import Unit, Town

BlUE = True
RED = False

# из окна chose hero приходит информация:
blue_hero = 1
red_hero = 1


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.resize(1920, 1080)
        self.setWindowTitle('PLAY')
        # self.setStyleSheet(main_background)

        self.texnologes = QPushButton('Технологии', self)
        self.texnologes.setStyleSheet(btm_start)
        self.texnologes.setGeometry(835, 950, 100, 40)

        self.next = QPushButton('Следующий ход', self)
        self.next.setStyleSheet(btm_start)
        self.next.setGeometry(985, 950, 100, 40)

        result, blue, red = field_creation()
        self.result = result

        self.x = (1920 - len(result[0]) * 80) // 2
        self.y = (920 - len(result) * 80) // 2
        self.main_label = QLabel(self)
        self.main_label.move(self.x, self.y)
        self.main_label.setPixmap(QPixmap('img/play.png'))

        self.blue_units = []
        self.red_units = []
        self.blue_towns = []
        self.red_towns = []

        self.blue_towns.append(Town().cord(self.x, self.y, *blue, self, BlUE))
        self.red_towns.append(Town().cord(self.x, self.y, *red, self, RED))

        self.blue_units.append(Unit(self.x, self.y, *blue, self))
        self.red_units.append(Unit(self.x, self.y, *red, self))

        self.oblast_f = False
        self.xod_f = True

        self.next.clicked.connect(self.confirmation)

    def confirmation(self):
        msgBox = QMessageBox()
        msgBox.setWindowTitle("Завершить ход?")
        msgBox.setText("")
        msgBox.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        ret = msgBox.exec_()

        if ret == QMessageBox.Yes:
            self.xod()

    def xod(self):
        self.xod_f = not self.xod_f

    def mousePressEvent(self, event):
        x, y = self.coord(event.x(), event.y())
        if self.xod_f:
            self.make_move(self.blue_units, x, y)
        else:
            self.make_move(self.red_units, x, y)

    def make_move(self, team, x, y):
        if not self.oblast_f:
            for i in team:
                if (x, y) == i.coords():
                    i.create_moves_oblast(self.blue_units, self.red_units)
                    self.active_unit = i
                    break
            self.oblast_f = True
        else:
            oblast = self.active_unit.oblast
            cord_x, cord_y = self.active_unit.coords()
            if abs(x - cord_x) < len(oblast) - 1 and abs(y - cord_y) < len(oblast) - 1:
                if oblast[abs(cord_y - self.active_unit.xod - y)][abs(cord_x - self.active_unit.xod - x)][1]:
                    self.active_unit.move_unit(x, y, self.blue_units, self.red_units)
            self.oblast_f = False
            self.active_unit.hide_oblast()

    def mouseDoubleClickEvent(self, event):
        x, y = self.coord(event.x(), event.y())

    def coord(self, x, y):
        x -= self.x
        y -= self.y
        return [int(x // 80), int(y // 80)]


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWindow()
    ex.show()
    sys.exit(app.exec_())
