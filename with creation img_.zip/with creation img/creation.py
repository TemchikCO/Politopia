from arhitecture import Cell, Town, Resources
from random import randrange
from creat_img import creat_img


def field_creation():
    blue = []
    red = []
    global result
    # потенциальное расширение на поле с регулируемым кол вом ячеек
    total = {'Town': 6, 'Resources': 28}
    result = [[Cell() for j in range(11)] for i in range(11)]
    for _ in range(6):
        i = randrange(1, 10)
        j = randrange(1, 10)
        while chek(i, j):
            i = randrange(1, 10)
            j = randrange(1, 10)
        result[i][j] = Town()
        if _ == 0:
            blue = (i, j)
        if _ == 1:
            red = (i, j)
    for _ in range(28):
        i = randrange(11)
        j = randrange(11)
        while type(result[i][j]) == type(Resources()) or type(result[i][j]) == type(Town()):
            i = randrange(11)
            j = randrange(11)
        result[i][j] = Resources()
    creat_img(result)
    return result, blue, red
    # вернуть двухмерный список обьктов класса Cell, Town, Resources


def chek(i, j):
    if type(Town()) in list(
            map(lambda x: type(x),
                result[i][j - 1: j + 2] + result[i + 1][j - 1: j + 2] + result[i - 1][j - 1: j + 2])):
        return True
    tot = []
    j_min = 1
    j_max = 2
    if j > 2:
        j_min = 2
    if j < 9:
        j_max = 3
    tot += result[i][j - j_min: j + j_max] + result[i + 1][j - j_min: j + j_max] + result[i - 1][j - j_min: j + j_max]
    if i > 1:
        tot += result[i - 2][j - j_min: j + j_max]
    if i < 9:
        tot += result[i + 2][j - j_min: j + j_max]
    if type(Town()) in list(map(lambda x: type(x), tot)):
        return True
    return False
