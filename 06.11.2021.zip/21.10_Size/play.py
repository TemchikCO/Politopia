import sys

from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QLabel, QGridLayout, QWidget, QVBoxLayout, \
    QGroupBox, QMessageBox
from PyQt5.QtCore import QRect, Qt

from style import btm_start, main_background
from creation import field_creation, TOWNS
from arhitecture import Unit, Town, Warrior, Players_Towns
from Get_heroes import Get_Heroes_Window
from Voin_info import Voin_info

BlUE = True
RED = False

# из окна chose hero приходит информация:
blue_hero = 1
red_hero = 1

BLUE_TOWNS_COUNT = 1
RED_TOWNS_COUNT = 1

class game_pole(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()


    def initUI(self):
        self.resize(1920, 1080)
        self.setWindowTitle('PLAY')
        # self.setStyleSheet(main_background)

        self.texnologes = QPushButton('Технологии', self)
        self.texnologes.setStyleSheet(btm_start)
        self.texnologes.setGeometry(835, 950, 100, 40)

        self.next = QPushButton('Следующий ход', self)
        self.next.setStyleSheet(btm_start)
        self.next.setGeometry(985, 950, 100, 40)

        result, self.blue, self.red = field_creation()
        self.result = result

        self.x = (1920 - len(result[0]) * 80) // 2
        self.y = (920 - len(result) * 80) // 2
        self.main_label = QLabel(self)
        self.main_label.move(self.x, self.y)
        self.main_label.setPixmap(QPixmap('img/play.png'))

        self.blue_units = []
        self.red_units = []
        self.blue_towns = []
        self.red_towns = []

        for coord in TOWNS:
            x, y = coord
            if coord == self.blue:
                self.blue_towns.append(self.result[x][y].cord(self.x, self.y, *self.blue, self, BlUE))
            elif coord == self.red:
                self.red_towns.append(self.result[x][y].cord(self.x, self.y, *self.red, self, RED))
            else:
                self.result[x][y].cord(self.x, self.y, x, y, self, None)

        self.blue_units.append(Unit(self.x, self.y, *self.blue, self, BlUE))
        self.red_units.append(Unit(self.x, self.y, *self.red, self, RED))

        self.blue_units[0].new_xod()
        self.red_units[0].new_xod()

        self.oblast_f = False
        self.xod_f = True
        self.active_unit_f = False

        self.next.clicked.connect(self.confirmation)

    def confirmation(self):
        msgBox = QMessageBox()
        msgBox.setWindowTitle("Завершить ход?")
        msgBox.setText("")
        msgBox.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        ret = msgBox.exec_()

        if ret == QMessageBox.Yes:
            self.xod()

    def comfirm_Town_capture(self):
        msgBox = QMessageBox()
        msgBox.setWindowTitle("Захватить город?")
        msgBox.setText("")
        msgBox.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        ret = msgBox.exec_()

        if ret == QMessageBox.Yes:
            if self.player == 'blue':
                self.Town_capture(self.blue_units, self.x_click, self.y_click)
            elif self.player == 'red':
                self.Town_capture(self.red_units, self.x_click, self.y_click)

    def xod(self):
        self.xod_f = not self.xod_f
        self.active_unit_f = False
        if self.xod_f:
            for i in self.blue_units:
                i.new_xod()
                i.atack_f = True
                # i.pict(QPixmap('img/heros_with_bow/Hero_3_with_bow.png'))
        else:
            for i in self.red_units:
                i.new_xod()
                i.atack_f = True

    def mousePressEvent(self, event):
        x, y = self.coord(event.x(), event.y())
        self.x_click = x
        self.y_click = y
        if self.xod_f:
            if (event.button() == Qt.LeftButton):
                self.make_move(self.blue_units, x, y)
            elif (event.button() == Qt.RightButton):
                for j in self.blue_units:
                    if (x, y) == j.coords():
                        for i in TOWNS:
                            if (x, y) == i and (x, y) != Players_Towns[0][:2]:
                                self.player = 'blue'
                                self.comfirm_Town_capture()
                            elif (x, y) == Players_Towns[0][:2]:
                                self.Town_control()
        else:
            if (event.button() == Qt.LeftButton):
                self.make_move(self.red_units, x, y)
            elif (event.button() == Qt.RightButton):
                for j in self.red_units:
                    if (x, y) == j.coords():
                        for i in TOWNS:
                            if (x, y) == i and (x, y) != Players_Towns[1][:2]:
                                self.player = 'red'
                                self.comfirm_Town_capture()
                            elif (x, y) == Players_Towns[1][:2]:
                                self.Town_control()

    def Town_control(self):
        self.Get_heroes_Window = Get_Heroes_Window()
        self.Voin_info_Window = Voin_info()

    def Town_capture(self, team, x, y):
        if team == self.blue_units:
            global BLUE_TOWNS_COUNT
            player = BlUE
            BLUE_TOWNS_COUNT += 1
        else:
            global RED_TOWNS_COUNT
            player = RED
            RED_TOWNS_COUNT += 1
        town: Town = self.result[x][y]
        town.player = player
        town.label()
        if player == BlUE:
            self.blue_towns.append(self.result[x][y])
        else:
            self.blue_towns.append(self.result[x][y])

    def make_move(self, team, x, y):
        if not self.oblast_f:
            for i in team:
                if (x, y) == i.coords():
                    i.create_moves_oblast(self.blue_units, self.red_units)
                    self.active_unit = i
                    self.active_unit_f = True
                    break
            if self.active_unit_f:
                self.oblast_f = True
        else:
            oblast = self.active_unit.oblast
            cord_x, cord_y = self.active_unit.coords()
            if (abs(x - cord_x) < len(oblast) - 1 and abs(y - cord_y) < len(oblast) - 1):
                if oblast[abs(cord_y - self.active_unit.xod_obl - y)][abs(cord_x - self.active_unit.xod_obl - x)][
                    1] and self.active_unit.xod:
                    self.active_unit.move_unit(x, y, self.blue_units, self.red_units)
                    self.active_unit.xod = False
                else:
                    self.active_unit.atack_un(x, y, self.xod_f, self.blue_units, self.red_units)
                    self.active_unit.atack_f = False
                self.useless()
            self.oblast_f = False
            self.active_unit.hide_oblast()

    def useless(self):
        if not self.active_unit.atack_f and not self.active_unit.xod:
            # изменить картинку self.active_unit.pict ...
            pass
        elif self.xod_f and self.active_unit.xod:
            for i in self.active_unit.atack:
                if i[1]:
                    return None
            # изменить картинку

    def mouseDoubleClickEvent(self, event):
        x, y = self.coord(event.x(), event.y())


    def coord(self, x, y):
        x -= self.x
        y -= self.y
        return [int(x // 80), int(y // 80)]
