# Here code praying to the GOD for protecting our open file from any bugs and other things.
# This is really crucial step! Be adviced to not remove it, even if you don`t believer.
# Please help as with it, ALLAH!!

import sys
from PyQt5 import uic, QtWidgets
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QMainWindow, QTableWidgetItem

from play import game_pole
from windows.others.start import Ui_MainWindow
from style import btm_start, main_background, text_style
from windows.characteristics.Hero1_characteristics import Hero_1_Window
from windows.characteristics.Hero2_characteristics import Hero_2_Window
from windows.characteristics.Hero3_characteristics import Hero_3_Window
from windows.characteristics.Hero4_characteristics import Hero_4_Window
from db.work_with_bd import db_select_short
from db_Read import db_Read

SCREEN_SIZE = [1920, 1080]
Blue_chose = None
Red_chose = None


class Start(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.db_read = db_Read()
        self.setupUi(self)
        self.chose_flag = True

        self.Hero_1_Window = Hero_1_Window()
        self.Hero_2_Window = Hero_2_Window()
        self.Hero_3_Window = Hero_3_Window()
        self.Hero_4_Window = Hero_4_Window()

        self.resize(*SCREEN_SIZE)
        self.setStyleSheet(main_background)

        self.pushButton.setStyleSheet(btm_start)
        self.pushButton_2.setStyleSheet(btm_start)
        self.pushButton_2.clicked.connect(self.DB_read)
        self.pushButton.clicked.connect(self.run)

    def reverse(self):
        uic.loadUi("ui/start.ui", self)

        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()

        self.pushButton.setStyleSheet(btm_start)
        self.pushButton_2.setStyleSheet(btm_start)

        self.pixmap = QPixmap('img/avatar.png')

        self.label.setPixmap(self.pixmap)
        self.label.setGeometry(810, 250, 300, 217)

        self.pushButton_2.setGeometry(820, 540, 280, 90)
        self.pushButton_2.clicked.connect(self.DB_read)
        self.pushButton.clicked.connect(self.run)

    def DB_read(self):
        self.db_read.show()
        self.db_read.tableWidget.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        result = db_select_short()
        if result:
            self.db_read.tableWidget.setRowCount(len(result))
            for i in range(len(result) - 1, -1, -1):
                self.db_read.tableWidget.setItem(i, 0, QTableWidgetItem(result[i][1]))
                self.db_read.tableWidget.setItem(i, 1, QTableWidgetItem(result[i][2]))
            self.db_read.tableWidget.resizeColumnsToContents()
            self.db_read.setStyleSheet(
                """QTableWidget::item {background-color: hotpink; color: black; font-size: 12px;}""")
        else:
            self.db_read.hide()

    def run(self):
        uic.loadUi("ui/chose_hero.ui", self)

        self.label.setStyleSheet(text_style)

        self.label_hero_1.setText("МАГИСТР ГОР")
        self.label_hero_1.setStyleSheet(text_style)

        self.label_hero_2.setText("ОХОТНИК")
        self.label_hero_2.setStyleSheet(text_style)

        self.label_hero_3.setText("ВЕЛИКИЙ НАЕЗДНИК")
        self.label_hero_3.setStyleSheet(text_style)

        self.label_hero_4.setText("ГЕРОЙ-САДОВОД")
        self.label_hero_4.setStyleSheet(text_style)

        self.ReverseButton.setStyleSheet(btm_start)
        self.ReverseButton.clicked.connect(self.reverse)

        self.Hero_1.setStyleSheet(btm_start)
        self.Hero_2.setStyleSheet(btm_start)
        self.Hero_3.setStyleSheet(btm_start)
        self.Hero_4.setStyleSheet(btm_start)

        self.Hero_1.clicked.connect(self.Hero_1_characteristic)
        self.Hero_2.clicked.connect(self.Hero_2_characteristic)
        self.Hero_3.clicked.connect(self.Hero_3_characteristic)
        self.Hero_4.clicked.connect(self.Hero_4_characteristic)

    def Hero_1_characteristic(self):
        self.btm = self.Hero_1
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()

        self.Hero_1_Window.show()
        if self.chose_flag:
            self.Hero_1_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_blue(1))
        else:
            self.Hero_1_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_red(1))
        self.Hero_1_Window.No_button.clicked.connect(self.run)

    def Hero_2_characteristic(self):
        self.btm = self.Hero_2
        self.Hero_1_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()

        self.Hero_2_Window.show()
        if self.chose_flag:
            self.Hero_2_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_blue(2))
        else:
            self.Hero_2_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_red(2))
        self.Hero_2_Window.No_button.clicked.connect(self.run)

    def Hero_3_characteristic(self):
        self.btm = self.Hero_3
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_4_Window.hide()

        self.Hero_3_Window.show()
        if self.chose_flag:
            self.Hero_3_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_blue(3))
        else:
            self.Hero_3_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_red(3))
        self.Hero_3_Window.No_button.clicked.connect(self.run)

    def Hero_4_characteristic(self):
        self.btm = self.Hero_4
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()

        self.Hero_4_Window.show()
        if self.chose_flag:
            self.Hero_4_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_blue(4))
        else:
            self.Hero_4_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_red(4))
        self.Hero_4_Window.No_button.clicked.connect(self.run)

    def hero_chosed_blue(self, number):
        self.Blue_chose = number
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()
        self.btm.setText('этот персоонаж выбран другим игроком')
        self.btm.blockSignals(True)

        self.chose_flag = False

    def hero_chosed_red(self, number):
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()
        self.Red_chose = number
        self.game = game_pole(self.Blue_chose, self.Red_chose)
        self.hide()
        self.game.show()


def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Start()
    ex.show()
    sys.__excepthook__ = except_hook
    sys.exit(app.exec_())
