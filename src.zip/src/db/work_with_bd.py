import sqlite3
from datetime import datetime


def db_select_short():
    try:
        connection = sqlite3.connect("db/games.db")
        cur = connection.cursor()
        cur.execute("SELECT ID, GAME_DATE, WINNER FROM GAMES")
        result = cur.fetchall()
        connection.close()
        return result
    except sqlite3.OperationalError:
        return False


def db_insert_short(winner=None):
    if winner:
        try:
            connection = sqlite3.connect("db/games.db")
            cur = connection.cursor()
            cur.execute("INSERT INTO GAMES (GAME_DATE, WINNER) VALUES('{}', '{}')".format(
                datetime.now().strftime('%Y.%m.%d %H:%M:%S')
                , winner
            ))
            connection.commit()
            connection.close()
            return True
        except sqlite3.OperationalError:
            return False
    else:
        return False
