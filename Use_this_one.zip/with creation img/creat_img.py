from PIL import Image


def creat_img(images, rows=11, cols=11):
    new_image = Image.new("RGB", (rows * 80, cols * 80), (0, 0, 0))
    for i in range(rows):
        for j in range(cols):
            im = Image.open(images[i][j].img())
            new_image.paste(im, (i * 80, j * 80))
    new_image.save('img/play.png')