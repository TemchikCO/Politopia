from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QLabel
from PyQt5.QtGui import QPixmap


class Cell:
    def __init__(self):
        pass

    def img(self):
        return 'img/cell_def.png'


class Town(Cell):
    def __init__(self):
        super().__init__()
        self.level = 0
        # УРОВЕНЬ ГОРОДа должен ОТОБРАЖАТСЯ КАРТИКОЙ

    def img(self):
        return 'img/town.png'


class Resources(Cell):
    def __init__(self):
        super().__init__()
        self.level = 0

    def img(self):
        return 'img/resource.png'


class Unit:
    # это две картинки: 1 -  мы видим всегда (сам unit), 2 - show(), когда нажимаем на Unitа (область возможного хода)
    def __init__(self, x, y, cord_x, cord_y, pole):
        self.x = x
        self.y = y
        self.pole = pole
        self.pict = QLabel(pole)
        self.pict.setGeometry(x + cord_x * 80, y + cord_y * 80, 80, 80)
        self.pict.setPixmap(QPixmap('img/Hero_3_with_bow.png'))
        pass

    def move(self):
        # реализовать область возможных ходов
        # обновить координаты в соответствии с кликнутым labelом
        pass

    # def img(self):
    #     'img/unit.png'

# technologies
