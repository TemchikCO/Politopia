from PIL import Image, ImageDraw
from math import cos, pi, sin


def pole_img(images, rows=11, cols=11):
    new_image = Image.new("RGB", (rows * 80, cols * 80), (0, 0, 0))
    for i in range(rows):
        for j in range(cols):
            im = Image.open(images[i][j].img())
            new_image.paste(im, (i * 80, j * 80))
    new_image.save('img/play.png')

def putalf(image, k):
    im = Image.open(image)
    pixels = im.load()
    for i in range(80):
        for j in range(80):
            r, g, b, a = pixels[i, j]
            if a != 0:
                a = k
            pixels[i, j] = (r, g, b, a)
    im.save(image[:-4] + 'alf.png')
    return image[:-4] + 'alf.png'
