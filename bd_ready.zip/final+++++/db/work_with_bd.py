import sqlite3
from datetime import datetime


def db_select_short():
    connection = sqlite3.connect("db/games.db")
    try:
        cur = connection.cursor()
        cur.execute("SELECT ID, GAME_DATE, WINNER FROM GAMES")
        result = cur.fetchall()
        connection.close()
        return result
    except sqlite3.OperationalError:
        connection.close()
        return False


def db_insert_short(winner=None):
    if winner:
        connection = sqlite3.connect("db/games.db")
        try:
            cur = connection.cursor()
            cur.execute("INSERT INTO GAMES (GAME_DATE, WINNER) VALUES('{}', '{}')".format(
                datetime.now().strftime('%Y.%m.%d %H:%M:%S')
                , winner
            ))
            connection.commit()
            connection.close()
            return True
        except sqlite3.OperationalError:
            connection.close()
            return False
    else:
        return False

# if db_insert_short("red"):
#    print("Insert complete")
# else:
#    print("Insert declined")

# db_select_short()
