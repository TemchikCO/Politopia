from PyQt5.QtWidgets import QMainWindow, QApplication, QPushButton, QLabel, QProgressBar
from PyQt5.QtGui import QPixmap

POLE_Y = 11
POLE_X = 11


class Cell:
    def __init__(self):
        pass

    def img(self):
        return 'img/cell/cell_def.png'


class Town(Cell):
    def __init__(self):
        super().__init__()

    def img(self):
        return 'img/cell/town/town_0.png'

    def cord(self, x, y, cord_x, cord_y, pole, player):
        super().__init__()
        self.level = 1
        self.x = x
        self.y = y
        self.cord_x = cord_x
        self.cord_y = cord_y
        self.pole = pole
        self.player = player
        self.label()

    def label(self):
        self.pict = QLabel(self.pole)
        self.pict.setGeometry(self.x + self.cord_x * 80, self.y + self.cord_y * 80, 80, 80)
        self.pict.setPixmap(QPixmap(f'img/cell/town/town_{self.level}.png'))

        self.border = QLabel(self.pole)
        self.border.setGeometry(self.x + self.cord_x * 80 - 80, self.y + self.cord_y * 80 - 80, 240, 240)
        if self.player:
            self.border.setPixmap(QPixmap('img/border/blue_border.png'))
        else:
            self.border.setPixmap(QPixmap('img/border/red_border.png'))

    def level_pl(self):
        self.level += 1
        self.img()


class Resources(Cell):
    def __init__(self):
        super().__init__()

    def img(self):
        return 'img/cell/resource.png'


class Unit:
    # это две картинки: 1 -  мы видим всегда (сам unit), 2 - show(), когда нажимаем на Unitа (область возможного хода)
    def __init__(self, x, y, cord_x, cord_y, pole, player):
        self.xod = False
        self.atack_f = True
        self.player = player
        self.cord_x = cord_x
        self.cord_y = cord_y
        self.x = x
        self.y = y

        self.pole = pole
        self.pict = QLabel(pole)
        self.pict.setGeometry(self.x + cord_x * 80, self.y + cord_y * 80, 80, 80)
        self.pict.setPixmap(QPixmap('img/heros_with_bow/Hero_3_with_bow.png'))

        self.xod_obl = 1
        self.atack_obl = 1
        self.oblast = []
        self.atack = []
        # (область возможного хода/атаки)
        for y in range(-self.xod_obl, self.xod_obl + 1):
            oblast = []
            for x in range(-self.xod_obl, self.xod_obl + 1):
                # new_move
                label = QLabel(pole)
                label.setPixmap(QPixmap('img/targets/new_move_terget.png'))
                label.setGeometry(self.x + (cord_x + x) * 80, self.y + (cord_y + y) * 80, 80, 80)
                label.hide()  # можно ли кликнуть на label

                oblast.append([label, False])
            self.oblast.append(oblast)

        for y in range(-self.atack_obl, self.atack_obl + 1):
            atack = []
            for x in range(-self.atack_obl, self.atack_obl + 1):
                label_ = QLabel(pole)
                label_.setPixmap(QPixmap('img/targets/new_atack_terget.png'))
                label_.setGeometry(self.x + (cord_x + x) * 80, self.y + (cord_y + y) * 80, 80, 80)
                label_.hide()
                atack.append([label_, False])
            self.atack.append(atack)

        self.hp = QProgressBar(self.pole)
        self.hp_fnc(10)
        # damage
        self.damage = 5

    def hp_fnc(self, vale):
        self.hp_vale = vale
        self.hp.setGeometry(self.x + self.cord_x * 80 + 10, self.y + self.cord_y * 80 + 65, 60, 15)
        self.hp.setTextVisible(False)
        self.hp.setMaximum(vale)
        self.hp.setValue(vale)

    def new_xod(self):
        self.xod = True

    def create_moves_oblast(self, blue_units, red_units):
        # срабатывает при нажатии на unit
        # генериться область в котороую можно сходить (с учетом исключений)
        # в Label
        y_a = 0
        y_b = 0
        x_a = 0
        x_b = 0
        if self.cord_y < 1:
            y_a = 1
        if self.cord_x < 1:
            x_a = 1
        if self.cord_y > POLE_Y - self.xod_obl - 1:
            y_b = 1
        if self.cord_x > POLE_X - self.xod_obl - 1:
            x_b = 1
        for y in range(-(self.xod_obl - y_a), self.xod_obl + 1 - y_b):
            for x in range(-(self.xod_obl - x_a), self.xod_obl + 1 - x_b):
                a = self.chek_unit(self.cord_x + x, self.cord_y + y, blue_units, red_units)
                if not a and self.xod:
                    self.oblast[y + self.xod_obl][x + self.xod_obl][0].show()
                    self.oblast[y + self.xod_obl][x + self.xod_obl][1] = True
                elif ((self.player and a == 'red') or (not self.player and a == 'blue')) and self.atack_f:
                    self.oblast[y + self.xod_obl][x + self.xod_obl][1] = False
                    self.atack[y + self.xod_obl][x + self.xod_obl][0].show()
                    self.atack[y + self.xod_obl][x + self.xod_obl][1] = True

    def atack_un(self, x, y, team, blue_units, red_units):
        if not team and self.atack_f:
            self.minus_hp(blue_units, x, y)
        elif self.atack_f:
            self.minus_hp(red_units, x, y)
        self.atack_f = False

    def minus_hp(self, units, x, y):
        for i in units:
            if (x, y) == i.coords():
                i.hp_vale -= self.damage
                i.hp.setValue(i.hp_vale)
                if i.hp_vale <= 0:
                    i.death(i, units)

    def hide_oblast(self):
        for i in range(len(self.oblast)):
            for j in range(len(self.oblast[0])):
                self.oblast[i][j][0].hide()
                self.oblast[i][j][1] = False
        for i in range(len(self.atack)):
            for j in range(len(self.atack[0])):
                self.atack[i][j][0].hide()
                self.atack[i][j][1] = False

    def death(self, unit, units):
        unit.pict.hide()
        unit.hide_oblast()
        unit.hp.hide()
        units.remove(unit)

    def coords(self):
        return self.cord_x, self.cord_y

    def chek_unit(self, x, y, blue_units, red_units):
        for i in blue_units:
            if (x, y) == i.coords():
                return 'blue'
        for i in red_units:
            if (x, y) == i.coords():
                return 'red'
        return False

    def move_oblast(self, x, y, blue_units, red_units):
        for y_ in range(-self.xod_obl, self.xod_obl + 1):
            for x_ in range(-self.xod_obl, self.xod_obl + 1):
                self.oblast[y_ + self.xod_obl][x_ + self.xod_obl][0].move(self.x + (x_ + x) * 80,
                                                                          self.y + (y_ + y) * 80)
        for y_ in range(-self.atack_obl, self.atack_obl + 1):
            for x_ in range(-self.atack_obl, self.atack_obl + 1):
                self.atack[y_ + self.atack_obl][x_ + self.atack_obl][0].move(self.x + (x_ + x) * 80, self.y + (y_ + y) * 80)
        self.create_moves_oblast(blue_units, red_units)

    def move_unit(self, x, y, blue_units, red_units):
        if self.oblast[abs(self.cord_y - self.xod_obl - y)][abs(self.cord_x - self.xod_obl - x)][1]:
            self.pict.move(self.x + 80 * x, self.y + 80 * y)
            self.move_oblast(x, y, blue_units, red_units)
            self.cord_x = x
            self.cord_y = y
            self.hp.move(self.x + x * 80 + 10, self.y + y * 80 + 65)


class Warrior(Unit):
    def __init__(self, x, y, cord_x, cord_y, pole, player):
        super().__init__(x, y, cord_x, cord_y, pole, player)
        self.damage = 10
        self.hp_fnc(15)


class Bow(Unit):
    def __init__(self, x, y, cord_x, cord_y, pole, player):
        super().__init__(x, y, cord_x, cord_y, pole, player)
        self.atack_obl = 2

    def create_moves_oblast(self, blue_units, red_units):
        # срабатывает при нажатии на unit
        # генериться область в котороую можно сходить (с учетом исключений)
        # в Label
        y_a = 0
        y_b = 0
        x_a = 0
        x_b = 0
        if self.cord_y < self.xod_obl:
            y_a = 1
        if self.cord_x < self.xod_obl:
            x_a = 1
        if self.cord_y > POLE_Y - self.xod_obl - 1:
            y_b = 1
        if self.cord_x > POLE_X - self.xod_obl - 1:
            x_b = 1
        for y in range(-(self.xod_obl - y_a), self.xod_obl + 1 - y_b):
            for x in range(-(self.xod_obl - x_a), self.xod_obl + 1 - x_b):
                a = self.chek_unit(self.cord_x + x, self.cord_y + y, blue_units, red_units)
                if not a and self.xod:
                    self.oblast[y + self.xod_obl][x + self.xod_obl][0].show()
                    self.oblast[y + self.xod_obl][x + self.xod_obl][1] = True
                else:
                    self.oblast[y + self.xod_obl][x + self.xod_obl][1] = False
        if self.cord_y < self.atack_obl:
            y_a = self.atack_obl - self.cord_y
        if self.cord_x < self.atack_obl:
            x_a = self.atack_obl - self.cord_x
        if self.cord_y > POLE_Y - self.atack_obl - 1:
            y_b = self.cord_y - (POLE_Y - self.atack_obl - 1)
        if self.cord_x > POLE_X - self.atack_obl - 1:
            x_b = self.cord_x - (POLE_X - self.atack_obl - 1)
        for y in range(-(self.atack_obl - y_a), self.atack_obl + 1 - y_b):
            for x in range(-(self.atack_obl - x_a), self.atack_obl + 1 - x_b):
                a = self.chek_unit(self.cord_x + x, self.cord_y + y, blue_units, red_units)
                if ((self.player and a == 'red') or (not self.player and a == 'blue')) and self.atack_f:
                    self.atack[y + self.xod_obl][x + self.xod_obl][0].show()
                    self.atack[y + self.xod_obl][x + self.xod_obl][1] = True
# тип лучник (пока не работает)
