def field_creation():
    # потенциальное расширение на поле с регулируемым кол вом ячеек
    # так же необходимо дополнить поле "рандомайзером ячеек"
    return [[Cell() for j in range(12)] for i in range(12)]
    pass


class Cell:
    def __init__(self):
        pass


class Town(Cell):
    pass


class Resources(Cell):
    pass


class Unit:
    def __init__(self):
        pass

    def move(self):
        pass

# technologies