import sys
from PyQt5 import uic, Qt
from PyQt5.QtWidgets import QApplication, QLabel, QMainWindow, QFileDialog

from start import Ui_MainWindow

SCREEN_SIZE = [1920, 1080]


class Start(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.resize(*SCREEN_SIZE)
        self.setStyleSheet("""
                            QMainWindow {
                                background-image: url("img.jpg");
                                background-repeat: no-repeat; 
                                background-position: center;
                            }
                        """)
        stylesheet = """QPushButton{font-style: oblique;
                                    font-weight: bold;
                                    border: 1px solid #1DA1F2;
                                    border-radius: 15px;
                                    color: #1DA1F2;
                                    background-color: #fff;
                                }
                                """
        self.pushButton.setStyleSheet(stylesheet)
        self.pushButton_2.setStyleSheet(stylesheet)
        self.pushButton.clicked.connect(self.run)

    def run(self):
        uic.loadUi("chose_hero.ui", self)
        self.radioButton.clicked.connect(self.hero_chosed)
        self.radioButton_2.clicked.connect(self.hero_chosed)
        self.radioButton_3.clicked.connect(self.hero_chosed)
        self.radioButton_4.clicked.connect(self.hero_chosed)

    def hero_chosed(self):
        uic.loadUi("play.ui", self)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Start()
    ex.show()
    sys.exit(app.exec_())
