# Here code praying to thr GOD for protecting our open file from any bugs and other things.
# This is really crucial step! Be adviced to not remove it, even if you don`t believer.
# Please help as with it, ALLAH!!

import sys
from PyQt5 import Qt, uic
from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QApplication, QLabel, QMainWindow, QFileDialog, QDialog, QInputDialog, QMessageBox, \
    QPushButton, QWidget
from PyQt5 import QtCore

from info_hunt1 import info_hunt1
from play import game_pole
from start import Ui_MainWindow
from style import btm_start, main_background, text_style
from Hero1_characteristics import Hero_1_Window
from Hero2_characteristics import Hero_2_Window
from Hero3_characteristics import Hero_3_Window
from Hero4_characteristics import Hero_4_Window

SCREEN_SIZE = [1920, 1080]
Blue_chose = None
Red_chose = None


class Start(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.money = 5
        self.chose_flag = True

        self.Hero_1_Window = Hero_1_Window()
        self.Hero_2_Window = Hero_2_Window()
        self.Hero_3_Window = Hero_3_Window()
        self.Hero_4_Window = Hero_4_Window()

        self.Hunt_flag = False
        self.Field_size = QWidget(self)
        uic.loadUi("ui/field_size_widget.ui", self.Field_size)
        self.Field_size.pushButton.setStyleSheet(btm_start)
        self.Field_size.hide()

        self.resize(*SCREEN_SIZE)
        self.setStyleSheet(main_background)

        self.pushButton.setStyleSheet(btm_start)
        self.pushButton_2.setStyleSheet(btm_start)
        self.pushButton.clicked.connect(self.size_chose)

    def size_chose(self):
        self.pushButton.hide()
        self.pushButton_2.hide()
        self.Field_size.setGeometry(800, 400, 350, 300)
        self.Field_size.setStyleSheet('background: black; color: white;')
        self.Field_size.show()
        self.Field_size.pushButton.clicked.connect(self.run)

    def reverse(self):
        self.Field_size.hide()
        uic.loadUi("ui/start.ui", self)

        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()

        self.pushButton.setStyleSheet(btm_start)
        self.pushButton_2.setStyleSheet(btm_start)

        self.pixmap = QPixmap('img/avatar.png')

        self.label.setPixmap(self.pixmap)
        self.label.setGeometry(810, 250, 300, 217)

        self.pushButton_2.setGeometry(820, 540, 280, 90)
        self.pushButton.clicked.connect(self.size_chose)

    def run(self):
        self.Width = self.Field_size.Width_box.value()
        self.Heigth = self.Field_size.Heigh_box.value()
        self.Field_size.hide()

        uic.loadUi("ui/chose_hero.ui", self)

        self.label_hero_1.setText("МАГИСТР ГОР")
        self.label_hero_1.setStyleSheet(text_style)

        self.label_hero_2.setText("ОХОТНИК")
        self.label_hero_2.setStyleSheet(text_style)

        self.label_hero_3.setText("ВЕЛИКИЙ НАЕЗДНИК")
        self.label_hero_3.setStyleSheet(text_style)

        self.label_hero_4.setText("ГЕРОЙ-САДОВОД")
        self.label_hero_4.setStyleSheet(text_style)

        self.ReverseButton.setStyleSheet(btm_start)
        self.ReverseButton.clicked.connect(self.reverse)

        self.Hero_1.setStyleSheet(btm_start)
        self.Hero_2.setStyleSheet(btm_start)
        self.Hero_3.setStyleSheet(btm_start)
        self.Hero_4.setStyleSheet(btm_start)

        self.Hero_1.clicked.connect(self.Hero_1_characteristic)
        self.Hero_2.clicked.connect(self.Hero_2_characteristic)
        self.Hero_3.clicked.connect(self.Hero_3_characteristic)
        self.Hero_4.clicked.connect(self.Hero_4_characteristic)
        # self.Next_button.clicked.connect(self.hero_chosed)

    def Hero_1_characteristic(self):
        self.btm = self.Hero_1
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()

        self.Hero_1_Window.show()
        if self.chose_flag:
            self.Hero_1_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_blue(1))
        else:
            self.Hero_1_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_red(1))
        self.Hero_1_Window.No_button.clicked.connect(self.run)

    def Hero_2_characteristic(self):
        self.btm = self.Hero_2
        self.Hero_1_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()

        self.Hero_2_Window.show()
        if self.chose_flag:
            self.Hero_2_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_blue(2))
        else:
            self.Hero_2_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_red(2))
        self.Hero_2_Window.No_button.clicked.connect(self.run)

    def Hero_3_characteristic(self):
        self.btm = self.Hero_3
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_4_Window.hide()

        self.Hero_3_Window.show()
        if self.chose_flag:
            self.Hero_3_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_blue(3))
        else:
            self.Hero_3_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_red(3))
        self.Hero_3_Window.No_button.clicked.connect(self.run)

    def Hero_4_characteristic(self):
        self.btm = self.Hero_4
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()

        self.Hero_4_Window.show()
        if self.chose_flag:
            self.Hero_4_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_blue(4))
        else:
            self.Hero_4_Window.Yes_button.clicked.connect(lambda: self.hero_chosed_red(4))
        self.Hero_4_Window.No_button.clicked.connect(self.run)

    def hero_chosed_blue(self, number):
        self.Blue_chose = number
        self.Hero_1_Window.hide()
        self.Hero_2_Window.hide()
        self.Hero_3_Window.hide()
        self.Hero_4_Window.hide()
        # self.btm.clicked.connect()  #- окошко того, что этот персоонаж уже выбран
        self.btm.setText('этот персоонаж выбран другим игроком')

        self.chose_flag = False

    def hero_chosed_red(self, number):
        self.Red_chose = number
        self.game = game_pole(self.Blue_chose, self.Red_chose)
        self.hide()
        self.game.show()

def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Start()
    ex.show()
    sys.__excepthook__ = except_hook
    sys.exit(app.exec_())
