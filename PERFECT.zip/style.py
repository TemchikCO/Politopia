btm_start = """QPushButton{font-style: oblique;
                                    font-weight: bold;
                                    border: 1px solid #1DA1F2;
                                    border-radius: 15px;
                                    color: #1DA1F2;
                                    background-color: #fff;
                                }
                                """
main_background = """
                            QMainWindow {
                                background-image: url("img/main.jpg");
                                background-repeat: no-repeat; 
                                background-position: center;
                            }
                        """
widget_background = """
                            QWidget {
                                background-image: url("img/main.jpg");
                                background-repeat: no-repeat; 
                                background-position: center;
                            }
                        """
text_style = """QLabel{ font-style: oblique; 
                font-weight: bolder; 
                text-decoration: blink; 
                color: white;
                } 
            """

text_style_blue = """QLabel{ font-style: oblique; 
                font-weight: bolder; 
                text-decoration: blink; 
                color: blue; 
                } 
            """

text_style_red = """QLabel{ font-style: oblique; 
                font-weight: bolder; 
                text-decoration: blink; 
                color: red; 
                } 
            """
