from PyQt5.QtGui import QPixmap
from PyQt5.QtWidgets import QPushButton, QLabel, QWidget, QMessageBox
from PyQt5.QtCore import Qt

from style import *
from creation import field_creation
from arhitecture import Unit, Town, Warrior, Bow, ResUnit, Resources, Magik
from windows.others.Get_heroes import Get_Heroes_Window
from windows.info.Voin_info import Voin_info
from windows.info.Bow_info import Bow_info
from windows.info.Start_info import Start_info
from windows.others.Blue_player_win import Blue_player_win_Window
from windows.others.Red_player_win import Red_player_win_Window
from creat_img import putalf
from windows.info.Mainer_info import Mainer_info
from windows.info.Magik_info import Magik_info
from windows.others.No_money_Window import No_money_Window
from windows.others.Blue_Technik import Blue_Technik_Window
from windows.others.Red_Technik import Red_Technik_Window
from windows.others.No_available import No_available

BlUE = True
RED = False

BLUE_TOWNS_COUNT = 1
RED_TOWNS_COUNT = 1


class game_pole(QWidget):
    def __init__(self, blue_chose, red_chose):
        super().__init__()
        self.Blue_technik = Blue_Technik_Window()
        self.Red_technik = Red_Technik_Window()
        self.No_available_window = No_available()

        self.Magik_info_Window = Magik_info()
        self.Start_info_Window = Start_info()
        self.Bow_info_Window = Bow_info()
        self.Voin_info_Window = Voin_info()
        self.Mainer_info_Window = Mainer_info()

        self.blue_chose = blue_chose
        self.red_chose = red_chose

        self.No_money_Window = No_money_Window()

        self.Blue_player_win_Window = Blue_player_win_Window()
        self.Red_player_win_Window = Red_player_win_Window()

        self.Blue_player_win_Window.New_game_button.clicked.connect(self.restart)
        self.Red_player_win_Window.New_game_button.clicked.connect(self.restart)

        self.Red_step = QLabel(self)
        self.Red_step.setText(f'Ход красного игрока')
        self.Red_step.setStyleSheet(text_style_red)
        self.Red_step.setGeometry(100, 70, 300, 30)
        self.Red_step.hide()

        self.Blue_step = QLabel(self)
        self.Blue_step.setText(f'Ход синего игрока')
        self.Blue_step.setStyleSheet(text_style_blue)
        self.Blue_step.setGeometry(1600, 70, 300, 30)
        self.Blue_step.show()

        self.blue_money = 3
        self.red_money = 3

        self.blue_money_per_step = 2
        self.red_money_per_step = 2

        self.Blue_money = QLabel(self)
        self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
        self.Blue_money.setGeometry(1600, 100, 300, 30)
        self.Blue_money.setStyleSheet(text_style_blue)
        self.Blue_money.show()

        self.Blue_money_per_step = QLabel(self)
        self.Blue_money_per_step.setText(f'Деньги синего игрока за ход = {self.blue_money_per_step}')
        self.Blue_money_per_step.setGeometry(1550, 160, 400, 30)
        self.Blue_money_per_step.setStyleSheet(text_style_blue)
        self.Blue_money_per_step.show()

        self.Blue_towns = QLabel(self)
        self.Blue_towns.setText(f'Количество городов синего персонажа = {BLUE_TOWNS_COUNT}')
        self.Blue_towns.setGeometry(1550, 130, 400, 30)
        self.Blue_towns.setStyleSheet(text_style_blue)
        self.Blue_towns.show()

        self.Red_money = QLabel(self)
        self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
        self.Red_money.setGeometry(100, 100, 300, 30)
        self.Red_money.setStyleSheet(text_style_red)
        self.Red_money.hide()

        self.Red_towns = QLabel(self)
        self.Red_towns.setText(f'Количество городов красного персонажа = {RED_TOWNS_COUNT}')
        self.Red_towns.setGeometry(50, 130, 400, 30)
        self.Red_towns.setStyleSheet(text_style_red)
        self.Red_towns.hide()

        self.Red_money_per_step = QLabel(self)
        self.Red_money_per_step.setText(f'Деньги красного игрока за ход = {self.red_money_per_step}')
        self.Red_money_per_step.setGeometry(50, 160, 400, 30)
        self.Red_money_per_step.setStyleSheet(text_style_red)
        self.Red_money_per_step.hide()

        self.Blue_Magik_Flag = False
        self.Blue_Mainer_Flag = False
        self.Blue_Bow_Flag = False
        self.Blue_Voin_Flag = False

        if blue_chose == 1:
            self.Blue_Magik_Flag = True
            self.Blue_technik.Magik_button.setText('Уже изучено')
        elif blue_chose == 2:
            self.Blue_Mainer_Flag = True
            self.Blue_technik.Mainer_button.setText('Уже изучено')
        elif blue_chose == 3:
            self.Blue_Bow_Flag = True
            self.Blue_technik.Bow_button.setText('Уже изучено')
        elif blue_chose == 4:
            self.Blue_Voin_Flag = True
            self.Blue_technik.Voin_button.setText('Уже изучено')


        self.Red_Magik_Flag = False
        self.Red_Mainer_Flag = False
        self.Red_Bow_Flag = False
        self.Red_Voin_Flag = False

        if red_chose == 1:
            self.Red_Magik_Flag = True
            self.Red_technik.Magik_button.setText('Уже изучено')
        elif red_chose == 2:
            self.Red_Mainer_Flag = True
            self.Red_technik.Mainer_button.setText('Уже изучено')
        elif red_chose == 3:
            self.Red_Bow_Flag = True
            self.Red_technik.Bow_button.setText('Уже изучено')
        elif red_chose == 4:
            self.Red_Voin_Flag = True
            self.Red_technik.Voin_button.setText('Уже изучено')

        self.initUI()

    def technik_window(self):
        if self.xod_f:
            self.Blue_technik.show()
            self.Blue_technik.Magik_button.clicked.connect(self.Magik_open)
            self.Blue_technik.Mainer_button.clicked.connect(self.Mainer_open)
            self.Blue_technik.Bow_button.clicked.connect(self.Bow_open)
            self.Blue_technik.Voin_button.clicked.connect(self.Voin_open)
        else:
            self.Red_technik.show()
            self.Red_technik.Magik_button.clicked.connect(self.Magik_open)
            self.Red_technik.Mainer_button.clicked.connect(self.Mainer_open)
            self.Red_technik.Bow_button.clicked.connect(self.Bow_open)
            self.Red_technik.Voin_button.clicked.connect(self.Voin_open)

    def Magik_open(self):
        if self.xod_f:
            if self.blue_money >= 6:
                self.Blue_Magik_Flag = True
                self.blue_money -= 6
                self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
                self.Blue_technik.Magik_button.setText('Уже изучено')
            else:
                self.No_money_Window.show()
        else:
            if self.red_money >= 6:
                self.Red_Magik_Flag = True
                self.red_money -= 6
                self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
                self.Red_technik.Magik_button.setText('Уже изучено')
            else:
                self.No_money_Window.show()

    def Mainer_open(self):
        if self.xod_f:
            if self.blue_money >= 6:
                self.Blue_Mainer_Flag = True
                self.blue_money -= 6
                self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
                self.Blue_technik.Mainer_button.setText('Уже изучено')
            else:
                self.No_money_Window.show()
        else:
            if self.red_money >= 6:
                self.Red_Mainer_Flag = True
                self.red_money -= 6
                self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
                self.Red_technik.Mainer_button.setText('Уже изучено')
            else:
                self.No_money_Window.show()

    def Bow_open(self):
        if self.xod_f:
            if self.blue_money >= 6:
                self.Blue_Bow_Flag = True
                self.blue_money -= 6
                self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
                self.Blue_technik.Bow_button.setText('Уже изучено')
            else:
                self.No_money_Window.show()
        else:
            if self.red_money >= 6:
                self.Red_Bow_Flag = True
                self.red_money -= 6
                self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
                self.Red_technik.Bow_button.setText('Уже изучено')
            else:
                self.No_money_Window.show()

    def Voin_open(self):
        if self.xod_f:
            if self.blue_money >= 6:
                self.Blue_Voin_Flag = True
                self.blue_money -= 6
                self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
                self.Blue_technik.Voin_button.setText('Уже изучено')
            else:
                self.No_money_Window.show()
        else:
            if self.red_money >= 6:
                self.Red_Voin_Flag = True
                self.red_money -= 6
                self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
                self.Red_technik.Voin_button.setText('Уже изучено')
            else:
                self.No_money_Window.show()

    def initUI(self):
        self.resize(1920, 1080)
        self.setWindowTitle('PLAY')

        self.texnologes = QPushButton('Технологии', self)
        self.texnologes.setStyleSheet(btm_start)
        self.texnologes.setGeometry(835, 950, 100, 40)
        self.texnologes.clicked.connect(self.technik_window)

        self.next = QPushButton('Следующий ход', self)
        self.next.setStyleSheet(btm_start)
        self.next.setGeometry(985, 950, 100, 40)
        self.main_label = QLabel(self)
        self.total_def_unit = []
        self.total_bow = []
        self.total_warrior = []
        self.total_farm = []

        self.total_magik = []

        self.blue_units = []
        self.red_units = []
        self.blue_towns = []
        self.red_towns = []
        self.blue_farm_units = []
        self.red_farm_units = []
        self.restart()

        self.next.clicked.connect(self.confirmation)

    def restart(self):
        global BLUE_TOWNS_COUNT, RED_TOWNS_COUNT
        BLUE_TOWNS_COUNT = 1
        RED_TOWNS_COUNT = 1
        self.Blue_player_win_Window.hide()
        self.Red_player_win_Window.hide()
        self.blue_money = 1
        self.red_money = 1
        result, self.blue, self.red, self.towns = field_creation()
        self.result = result

        self.x = (1920 - len(result[0]) * 80) // 2
        self.y = (920 - len(result) * 80) // 2

        self.main_label.move(self.x, self.y)
        self.main_label.setPixmap(QPixmap('img/play.png'))

        for i in self.blue_units:
            i.hide_()
            i.kill()
        for i in self.red_units:
            i.hide_()
            i.kill()
        for i in self.red_towns:
            i.hide_()
            i.kill()
        for i in self.blue_towns:
            i.hide_()
            i.kill()

        self.blue_units = []
        self.red_units = []
        self.blue_towns = []
        self.red_towns = []
        self.blue_farm_units = []
        self.red_farm_units = []

        for coord in self.towns:
            x, y = coord
            if coord == self.blue:
                self.blue_towns.append(self.result[x][y].cord(self.x, self.y, *self.blue, self, BlUE))
            elif coord == self.red:
                self.red_towns.append(self.result[x][y].cord(self.x, self.y, *self.red, self, RED))
            else:
                self.result[x][y].cord(self.x, self.y, x, y, self, None)
        self.xod_f = True
        self.xod()
        self.xod()

        for i in range(200 - len(self.total_def_unit)):
            a = Unit(self.x, self.y, *self.blue, self, None, self.blue_chose, self.red_chose)
            a.hide_()
            self.total_def_unit.append(a)

        for i in range(200 - len(self.total_magik)):
            a = Magik(self.x, self.y, *self.blue, self, None, self.blue_chose, self.red_chose)
            a.hide_()
            self.total_magik.append(a)

        for i in range(200 - len(self.total_bow)):
            a = Bow(self.x, self.y, *self.blue, self, None, self.blue_chose, self.red_chose)
            a.hide_()
            self.total_bow.append(a)

        for i in range(200 - len(self.total_warrior)):
            a = Warrior(self.x, self.y, *self.blue, self, None, self.blue_chose, self.red_chose)
            a.hide_()
            self.total_warrior.append(a)

        for i in range(200 - len(self.total_farm)):
            a = ResUnit(self.x, self.y, *self.blue, self, None, self.blue_chose, self.red_chose)
            a.hide_()
            self.total_farm.append(a)

        a = self.total_def_unit[-1]
        a.show_()
        a.teleport(*self.blue, self.blue_units, self.red_units, BlUE)
        self.blue_units.append(a)
        self.total_def_unit.remove(a)

        a = self.total_def_unit[-1]
        a.teleport(*self.red, self.blue_units, self.red_units, RED)
        a.show_()
        self.red_units.append(a)
        self.total_def_unit.remove(a)

        self.blue_units[0].new_xod()
        self.red_units[0].new_xod()

        self.oblast_f = False
        self.active_unit_f = False

        self.Blue_towns.setText(f'Количество городов синего персонажа = {BLUE_TOWNS_COUNT}')
        self.Red_towns.setText(f'Количество городов красного персонажа = {RED_TOWNS_COUNT}')

    def confirmation(self):
        msgBox = QMessageBox()
        msgBox.setWindowTitle("Завершить ход?")
        msgBox.setText("")
        msgBox.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        ret = msgBox.exec_()

        if ret == QMessageBox.Yes:
            self.xod()

    def comfirm_Town_capture(self):
        msgBox = QMessageBox()
        msgBox.setWindowTitle("Захватить город?")
        msgBox.setText("")
        msgBox.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        ret = msgBox.exec_()

        if ret == QMessageBox.Yes:
            if self.player == 'blue':
                self.Town_capture(self.blue_units, self.x_click, self.y_click)
            elif self.player == 'red':
                self.Town_capture(self.red_units, self.x_click, self.y_click)

    def xod(self):
        if BLUE_TOWNS_COUNT == 0:
            self.Red_player_win_Window.show()
        elif RED_TOWNS_COUNT == 0:
            self.Blue_player_win_Window.show()
        if self.xod_f:
            for i in self.blue_units:
                i.new_xod()
                i.atack_f = True
                i.pict.setPixmap(QPixmap(i.get_img()))
        else:
            for i in self.red_units:
                i.new_xod()
                i.atack_f = True
                i.pict.setPixmap(QPixmap(i.get_img()))
        self.money()

        self.xod_f = not self.xod_f
        self.active_unit_f = False

        if not self.xod_f:
            self.Red_money.show()
            self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
            self.Red_step.show()

            self.Blue_money.hide()
            self.Blue_towns.hide()
            self.Blue_step.hide()
            self.Blue_money_per_step.hide()

            self.Red_towns.show()
            self.Red_money_per_step.show()
        else:
            self.Blue_money.show()
            self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
            self.Blue_step.show()

            self.Red_step.hide()
            self.Red_money.hide()
            self.Red_towns.hide()
            self.Red_money_per_step.hide()

            self.Blue_towns.show()
            self.Blue_money_per_step.show()

    def money(self):
        self.a = 0
        if self.xod_f:
            for i in self.blue_farm_units:
                x, y = i.coords()
                if type(self.result[x][y]) == type(Resources()):
                    self.a += 1
            self.blue_money += BLUE_TOWNS_COUNT * 2 + self.a
            self.Blue_money_per_step.setText(f'Деньги синего игрока за ход = {BLUE_TOWNS_COUNT * 2 + self.a}')
        else:
            for i in self.red_farm_units:
                x, y = i.coords()
                if type(self.result[x][y]) == type(Resources()):
                    self.a += 1
            self.red_money += RED_TOWNS_COUNT * 2 + self.a
            self.Red_money_per_step.setText(f'Деньги красного игрока за ход = {RED_TOWNS_COUNT * 2 + self.a}')

    def mousePressEvent(self, event):
        x, y = self.coord(event.x(), event.y())
        self.x_click = x
        self.y_click = y
        if self.xod_f:
            if (event.button() == Qt.LeftButton):
                self.make_move(self.blue_units, x, y)
            elif (event.button() == Qt.RightButton):
                for j in self.blue_units:
                    if (x, y) == j.coords():
                        if not any(town.coords() == (x, y) for town in self.blue_towns):
                            self.function(j)
                            return None

                for town in self.blue_towns:
                    if town.coords() == (x, y):
                        self.Town_control(x, y)
        else:
            if (event.button() == Qt.LeftButton):
                self.make_move(self.red_units, x, y)
            elif (event.button() == Qt.RightButton):
                for j in self.red_units:
                    if (x, y) == j.coords():
                        if not any(town.coords() == (x, y) for town in self.red_towns):
                            self.function(j)
                            return None

                for town in self.red_towns:
                    if town.coords() == (x, y):
                        self.Town_control(x, y)

    def heal(self, unit, towns):
        if unit.xod and unit.atack_f:
            for i in towns:
                x, y = i.coords()
                if (x - 1 <= unit.cord_x <= x + 1) and (y - 1 <= unit.cord_y <= y + 1):
                    if self.dialog():
                        unit.heal_un()
                        self.active_unit = unit
                        self.useless()

    def dialog(self):
        msgBox = QMessageBox()
        msgBox.setWindowTitle("Вылечить?")
        msgBox.setText("Unit потеряет возможность ходить и аттоковать в этот ход")
        msgBox.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        ret = msgBox.exec_()

        if ret == QMessageBox.Yes:
            return True

    def function(self, unit):
        if self.xod_f:
            if any((self.x_click, self.y_click) == town[:2] for town in self.towns):
                self.player = 'blue'
                self.comfirm_Town_capture()
            else:
                self.heal(unit, self.blue_towns)
        else:
            if any((self.x_click, self.y_click) == town[:2] for town in self.towns):
                self.player = 'red'
                self.comfirm_Town_capture()
            else:
                self.heal(unit, self.red_towns)

    def Town_control(self, x, y):
        self.Get_heroes_Window = Get_Heroes_Window()
        self.Get_heroes_Window.show()
        self.Get_heroes_Window.Voin_info.clicked.connect(self.Voin_info)
        self.Get_heroes_Window.Bow_info.clicked.connect(self.Bow_info)
        self.Get_heroes_Window.Start_info.clicked.connect(self.Start_info)
        self.Get_heroes_Window.Mainer_info.clicked.connect(self.Mainer_info)
        self.Get_heroes_Window.Magik_info.clicked.connect(self.Magik_info)
        self.Get_heroes_Window.Get_Start.clicked.connect(lambda: self.chek_un(x, y, 'unit'))
        self.Get_heroes_Window.Get_Voin.clicked.connect(lambda: self.chek_un(x, y, 'warrior'))
        self.Get_heroes_Window.Get_Bow.clicked.connect(lambda: self.chek_un(x, y, 'bow'))
        self.Get_heroes_Window.Get_Mainer.clicked.connect(lambda: self.chek_un(x, y, 'res_unit'))
        self.Get_heroes_Window.Get_Magik.clicked.connect(lambda: self.chek_un(x, y, 'magik'))
        self.active_unit_f = False

    def chek_un(self, x, y, unit_type):
        for i in self.blue_units:
            if (x, y) == i.coords():
                return None
        for i in self.red_units:
            if (x, y) == i.coords():
                return None
        if unit_type == 'unit':
            self.unit(x, y)
        elif unit_type == 'warrior':
            self.warrior(x, y)
        elif unit_type == 'bow':
            self.bow(x, y)
        elif unit_type == 'res_unit':
            self.res_unit(x, y)
        elif unit_type == 'magik':
            self.magik(x, y)
        self.Get_heroes_Window.hide()

    def magik(self, x, y):
        if self.xod_f:
            if self.Blue_Magik_Flag:
                if self.blue_money >= 6:
                    a = self.total_magik[-1]
                    a.show_()
                    self.blue_money -= 6
                    self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
                    a.teleport(x, y, self.blue_units, self.red_units, BlUE)
                    self.blue_units.append(a)
                    self.active_unit = a
                    self.useless()
                    self.total_magik.remove(a)
                else:
                    self.No_money_Window.show()
            else:
                self.No_available_window.show()
        else:
            if self.Red_Magik_Flag:
                if self.red_money >= 6:
                    a = self.total_magik[-1]
                    a.show_()
                    self.red_money -= 6
                    self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
                    a.teleport(x, y, self.blue_units, self.red_units, RED)
                    self.red_units.append(a)
                    self.active_unit = a
                    self.useless()
                    self.total_magik.remove(a)
                else:
                    self.No_money_Window.show()
            else:
                self.No_available_window.show()

    def unit(self, x, y):
        if self.xod_f:
            if self.blue_money >= 2:
                a = self.total_def_unit[-1]
                a.show_()
                self.blue_money -= 2
                self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
                a.teleport(x, y, self.blue_units, self.red_units, BlUE)
                self.blue_units.append(a)
                self.active_unit = a
                self.useless()
                self.total_def_unit.remove(a)
            else:
                self.No_money_Window.show()
        else:
            if self.red_money >= 2:
                a = self.total_def_unit[-1]
                a.show_()
                self.red_money -= 2
                self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
                a.teleport(x, y, self.blue_units, self.red_units, RED)
                self.red_units.append(a)
                self.active_unit = a
                self.useless()
                self.total_def_unit.remove(a)
            else:
                self.No_money_Window.show()

    def warrior(self, x, y):
        if self.xod_f:
            if self.Blue_Voin_Flag:
                if self.blue_money >= 7:
                    a = self.total_warrior[-1]
                    a.show_()
                    self.blue_money -= 7
                    self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
                    a.teleport(x, y, self.blue_units, self.red_units, BlUE)
                    self.blue_units.append(a)
                    self.active_unit = a
                    self.useless()
                    self.total_warrior.remove(a)
                else:
                    self.No_money_Window.show()
            else:
                self.No_available_window.show()
        else:
            if self.Red_Voin_Flag:
                if self.red_money >= 7:
                    a = self.total_warrior[-1]
                    a.show_()
                    self.red_money -= 7
                    self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
                    a.teleport(x, y, self.blue_units, self.red_units, RED)
                    self.red_units.append(a)
                    self.active_unit = a
                    self.useless()
                    self.total_warrior.remove(a)
                else:
                    self.No_money_Window.show()
            else:
                self.No_available_window.show()

    def bow(self, x, y):
        if self.xod_f:
            if self.Blue_Bow_Flag:
                if self.blue_money >= 5:
                    a = self.total_bow[-1]
                    a.show_()
                    self.blue_money -= 5
                    self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
                    a.teleport(x, y, self.blue_units, self.red_units, BlUE)
                    self.blue_units.append(a)
                    self.active_unit = a
                    self.useless()
                    self.total_bow.remove(a)
                else:
                    self.No_money_Window.show()
            else:
                self.No_available_window.show()
        else:
            if self.Red_Bow_Flag:
                if self.red_money >= 5:
                    a = self.total_bow[-1]
                    a.show_()
                    self.red_money -= 5
                    self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
                    a.teleport(x, y, self.blue_units, self.red_units, RED)
                    self.red_units.append(a)
                    self.active_unit = a
                    self.useless()
                    self.total_bow.remove(a)
                else:
                    self.No_money_Window.show()
            else:
                self.No_available_window.show()

    def res_unit(self, x, y):
        if self.xod_f:
            if self.Blue_Mainer_Flag:
                if self.blue_money >= 6:
                    a = self.total_farm[-1]
                    a.show_()
                    self.blue_money -= 6
                    self.Blue_money.setText(f'Деньги синего игрока = {self.blue_money}')
                    a.teleport(x, y, self.blue_units, self.red_units, BlUE)
                    self.blue_units.append(a)
                    self.blue_farm_units.append(a)
                    self.active_unit = a
                    self.useless()
                    self.total_farm.remove(a)
                else:
                    self.No_money_Window.show()
            else:
                self.No_available_window.show()
        else:
            if self.Red_Mainer_Flag:
                if self.red_money >= 6:
                    a = self.total_farm[-1]
                    a.show_()
                    self.red_money -= 6
                    self.Red_money.setText(f'Деньги красного игрока = {self.red_money}')
                    a.teleport(x, y, self.blue_units, self.red_units, RED)
                    self.red_units.append(a)
                    self.red_farm_units.append(a)
                    self.active_unit = a
                    self.useless()
                    self.total_farm.remove(a)
                else:
                    self.No_money_Window.show()
            else:
                self.No_available_window.show()

    def Mainer_info(self):
        self.Mainer_info_Window.show()

    def Voin_info(self):
        self.Voin_info_Window.show()

    def Bow_info(self):
        self.Bow_info_Window.show()

    def Start_info(self):
        self.Start_info_Window.show()

    def Magik_info(self):
        self.Magik_info_Window.show()

    def No_money_Window_close(self):
        self.No_money_Window.hide()

    def Town_capture(self, team, x, y):
        global BLUE_TOWNS_COUNT
        global RED_TOWNS_COUNT
        if team == self.blue_units:
            player = BlUE
            BLUE_TOWNS_COUNT += 1
        else:
            player = RED
            RED_TOWNS_COUNT += 1
        town: Town = self.result[x][y]
        town.player = player
        town.label()
        if player == BlUE:
            self.blue_towns.append(town)
            if town in self.red_towns:
                RED_TOWNS_COUNT -= 1
                self.red_towns.remove(town)
        else:
            self.red_towns.append(town)
            if town in self.blue_towns:
                BLUE_TOWNS_COUNT -= 1
                self.blue_towns.remove(town)

        self.Blue_money_per_step.setText(f'Деньги синего игрока за ход = {BLUE_TOWNS_COUNT * 2 + self.a}')
        self.Red_money_per_step.setText(f'Деньги красного игрока за ход = {RED_TOWNS_COUNT * 2 + self.a}')

        self.Blue_towns.setText(f'Количество городов синего персонажа = {BLUE_TOWNS_COUNT}')
        self.Red_towns.setText(f'Количество городов красного персонажа = {RED_TOWNS_COUNT}')

    def make_move(self, team, x, y):
        if not self.active_unit_f:
            for i in team:
                if (x, y) == i.coords():
                    i.create_moves_oblast(self.blue_units, self.red_units)
                    self.active_unit = i
                    self.active_unit_f = True
                    break
            if self.active_unit_f:
                self.oblast_f = True
        else:
            oblast = self.active_unit.oblast
            cord_x, cord_y = self.active_unit.coords()
            if (abs(x - cord_x) < len(oblast) - 1 and abs(y - cord_y) < len(oblast) - 1):
                if oblast[abs(cord_y - self.active_unit.xod_obl - y)][abs(cord_x - self.active_unit.xod_obl - x)][
                    1] and self.active_unit.xod:
                    self.active_unit.move_unit(x, y, self.blue_units, self.red_units)
                    self.active_unit.xod = False
                    self.useless()
            if (abs(cord_y - self.active_unit.atack_obl - y) < len(self.active_unit.atack) and abs(
                    cord_x - self.active_unit.atack_obl - x) < len(self.active_unit.atack)):
                if self.active_unit.atack[abs(cord_y - self.active_unit.atack_obl - y)][
                    abs(cord_x - self.active_unit.atack_obl - x)][
                    1]:
                    self.active_unit.atack_un(x, y, self.xod_f, self.blue_units, self.red_units)
                    self.active_unit.atack_f = False
                    self.useless()
            self.active_unit_f = False
            self.active_unit.hide_oblast()

    def useless(self):
        if not self.active_unit.xod and not self.active_unit.atack_f:
            self.active_unit.pict.setPixmap(QPixmap(putalf(self.active_unit.get_img(), int(256 * 0.25))))
        else:
            self.active_unit.pict.setPixmap(QPixmap(putalf(self.active_unit.get_img(), int(256 * 0.75))))

    def coord(self, x, y):
        x -= self.x
        y -= self.y
        return [int(x // 80), int(y // 80)]
