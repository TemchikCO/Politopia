import sys

from PyQt5.QtWidgets import QApplication, QWidget, QWidget, \
    QPushButton, QLCDNumber, QLabel, QLineEdit, QMainWindow
from PyQt5 import QtCore, QtGui, QtWidgets


class NumberError(Exception):
    pass


class FileNotFoundError(Exception):
    pass


class ValueError(Exception):
    pass


# noinspection PyTypeChecker
class Ui_MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setMinimumSize(QtCore.QSize(150, 20))
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayoutWidget_2 = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget_2.setGeometry(QtCore.QRect(70, 110, 268, 101))
        self.verticalLayoutWidget_2.setObjectName("verticalLayoutWidget_2")
        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.verticalLayoutWidget_2)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label.setMinimumSize(QtCore.QSize(50, 20))
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.lineEdit = QtWidgets.QLineEdit(self.verticalLayoutWidget_2)
        self.lineEdit.setMinimumSize(QtCore.QSize(150, 20))
        self.lineEdit.setObjectName("lineEdit")
        self.horizontalLayout.addWidget(self.lineEdit)
        self.pushButton = QtWidgets.QPushButton(self.verticalLayoutWidget_2)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout.addWidget(self.pushButton)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_4 = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_4.setMinimumSize(QtCore.QSize(70, 0))
        self.label_4.setObjectName("label_4")
        self.horizontalLayout_2.addWidget(self.label_4)
        self.spinBox = QtWidgets.QSpinBox(self.verticalLayoutWidget_2)
        self.spinBox.setMinimumSize(QtCore.QSize(150, 0))
        self.spinBox.setObjectName("spinBox")
        self.horizontalLayout_2.addWidget(self.spinBox)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_2 = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_2.setObjectName("label_2")
        self.horizontalLayout_3.addWidget(self.label_2)
        self.spinBox_2 = QtWidgets.QSpinBox(self.verticalLayoutWidget_2)
        self.spinBox_2.setMinimumSize(QtCore.QSize(150, 0))
        self.spinBox_2.setObjectName("spinBox_2")
        self.horizontalLayout_3.addWidget(self.spinBox_2)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.label_3 = QtWidgets.QLabel(self.verticalLayoutWidget_2)
        self.label_3.setObjectName("label_3")
        self.horizontalLayout_4.addWidget(self.label_3)
        self.spinBox_3 = QtWidgets.QSpinBox(self.verticalLayoutWidget_2)
        self.spinBox_3.setMinimumSize(QtCore.QSize(150, 0))
        self.spinBox_3.setObjectName("spinBox_3")
        self.horizontalLayout_4.addWidget(self.spinBox_3)
        self.verticalLayout.addLayout(self.horizontalLayout_4)
        self.verticalLayout_2.addLayout(self.verticalLayout)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 18))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.pushButton.clicked.connect(self.run)

    def run(self):
        our_file = str(self.lineEdit.text())
        with open(our_file) as file:
            with open("output.txt", "w"):
                listed = []
                a = 0
                lines = file.readlines()
                if lines:
                    for i in lines:
                        self.list.append(int(i))
                    self.spinBox.setMaximum(listed)
                    self.spinBox_2.setMinimum(listed)
                    for i in self.list:
                        self.a += i
                    averege = a / len(self.list)
                    self.spinBox_3.setValue(averege)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Имя файла:"))
        self.pushButton.setText(_translate("MainWindow", "Рассчитать"))
        self.label_4.setText(_translate("MainWindow", "Максильное значение:"))
        self.label_2.setText(_translate("MainWindow", "Минимальное значение:"))
        self.label_3.setText(_translate("MainWindow", "Среднее значение:"))


if __name__ == '__main__':
    try:
        app = QApplication(sys.argv)
        ex = Ui_MainWindow()
        ex.show()
        sys.exit(app.exec_())
    except FileNotFoundError:
        print("файл не найден")
    except ValueError:
        print("плохой формат")
###########################################################################################
###########################################################################################
###########################################################################################
###########################################################################################
###########################################################################################
###########################################################################################


import sys

from PyQt5.QtWidgets import QApplication, QWidget, QWidget, \
    QPushButton, QLCDNumber, QLabel, QLineEdit, QMainWindow
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5 import uic


class FileNotFoundError(Exception):
    pass


class ValueError(Exception):
    pass


# noinspection PyTypeChecker
class Ui_MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('1212.ui', self)
        #self.setupUi(self)
        self.pushButton.clicked.connect(self.run)


    def run(self):
        our_file = str(self.lineEdit.text())
        with open(our_file) as file:
            with open("output.txt", "w"):
                listed = []
                a = 0
                lines = file.readlines().split(' ')
                for i in lines:
                    lines[i] = int(lines[i])
                print(lines)
                for i in lines:
                    self.listed.append(int(i))
                    print(listed)
                    self.spinBox.setMaximum(listed)
                    self.spinBox_2.setMinimum(listed)
                    for i in self.list:
                        self.a += i
                    averege = a / len(self.list)
                    self.spinBox_3.setValue(averege)


if __name__ == '__main__':
    try:
        app = QApplication(sys.argv)
        ex = Ui_MainWindow()
        ex.show()
        sys.exit(app.exec_())
    except FileNotFoundError:
        print("файл не найден")
    except ValueError:
        print("плохой формат")
